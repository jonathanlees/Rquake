SaveCSV <-
  function(nh, g )
  {

    ##   destdir = "."
    
    twpx= g$WPX

  ##   message("SaveCSV test")
  ##   message(twpx$sec)
  ##   message(data.frame(twpx))

    if( identical(legitWPX(twpx, quiet=FALSE),0)  ) {

      message("Need to click on screen, register picks (GPIX, or YPIX)" )
    }
    else
      {
        nona = which( is.na(twpx$tag) )
        
        if(length(nona)>0)
          {
            twpx = RSEIS::deleteWPX(twpx, nona)
          }
        if(length(twpx$tag)<1 )
          {
            
            g$action="donothing"
            invisible(list(global.vars=g))
          }
        
        RDATES = Qrangedatetime(twpx)
        
        fout1 = PCfiledatetime(RDATES$min, 0)
        
        fout2 = paste(fout1,"csv", sep="." )
        
        ##      fout3 = paste(destdir, fout2, sep="/")
        if(is.null(g$destdir)) { g$destdir='.' }
           
        fout2 = paste(g$destdir, fout2, sep="/")
        
        write.csv(twpx, file=fout2)
        g$LWPX = twpx
        g$WPX = RSEIS::cleanWPX()
        
      }
    g$zloc = list(x=NULL, y=NULL)
    g$action="donothing"
    invisible(list(global.vars=g))
  }
