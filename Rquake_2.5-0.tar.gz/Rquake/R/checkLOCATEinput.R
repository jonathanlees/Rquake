checkLOCATEinput<-function(Ldat, EQ, vel=NULL)
    {

      if( any( !is.numeric(Ldat$x) ) |
         any( !is.numeric(Ldat$y) ) |
         any( !is.numeric(Ldat$z) ) )
          {
              message('STOP:\n')
              warning(' Ldat has bad data.\n')
              return(FALSE)
          }

      if( any( !is.numeric(EQ$x) ) |
         any( !is.numeric(EQ$y) ) |
         any( !is.numeric(EQ$z) ) |
         any( !is.numeric(EQ$t) )
         )
          {
              message('STOP:\n')
              warning(' EQ has bad/missing data.\n')
              return(FALSE)
          }


      ##### passes inspection

      return(TRUE)

    }
